public class DLBTrie implements DictionaryInterface
{
	private Node root;
	private Node curChar = root;
	private Node prevChar = root;
	
	public class Node{
		char nodeChar;
		Node right;
		Node down;
		boolean isWord = false;
		public Node (char c){
			nodeChar = c;
		}
	}
	
	public DLBTrie(){
		
	}
	
	public boolean add(String word){
		word = word.toLowerCase();
		if(word == null || word.length() > 16){
			return false;
		}
		else{
				curChar = root;
				prevChar = root;
				if(curChar == null){
					curChar = new Node(word.charAt(0));
					root = curChar;
				}
				for(int i = 0; i <= word.length()-1; i++){
					if( keepGoinRightSearch(word.charAt(i))){
						prevChar = curChar;
						curChar = curChar.down;
					}
					else{
						if(curChar == null){
							prevChar.down = new Node(word.charAt(i));
							prevChar = prevChar.down;
							curChar = prevChar.down;
						}
						else{
							prevChar = curChar;
							curChar.right = new Node(word.charAt(i));
							prevChar = prevChar.right;
							curChar = prevChar.down;
						}
					}
				}
				prevChar.isWord = true;
		}
		return true;
	}
	
	public boolean keepGoinRightSearch(char c){
		while(lookRight(curChar) && curChar.nodeChar != c) {
			prevChar = curChar;
			curChar = curChar.right;
		}
		if(curChar != null && (curChar.nodeChar == c))
			return true;
		return false;
	}
	
	public boolean lookRight(Node currentNode){
		if(currentNode != null && currentNode.right != null)
			return true;
		return false;
	}
	
	public int search(StringBuilder inputStringBuilder)
	{
		String input = inputStringBuilder.toString();
		input = input.toLowerCase();
		curChar = root;
		prevChar = root;
		if(root != null && input.length() <= 16){
			for(int i = 0; i <= input.length()-1; i++){
				if(!keepGoinRightSearch(input.charAt(i))){
					return 0;
				}
				else{
					if (i == input.length()-1 && curChar.isWord == false && curChar.down != null)
						return 1;
					if (i == input.length()-1 && curChar.isWord == true && curChar.down == null)
						return 2;
					if (i == input.length()-1 && curChar.isWord == true && curChar.down != null)
						return 3;
				}
				curChar = curChar.down;
			}
		}
		return 0;
	}
}