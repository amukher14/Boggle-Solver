import java.io.*;
import java.util.*;
public class MyBoggle {
	public static void main(String [] args) throws IOException
	{
		System.out.println( "WELCOME TO BOGGLE! \n To use the faster search speed type as an arguement -d dlb when starting the program \n to use the default speed use -d simple type as an arguement when starting the program \n To select a board use the argument -b boardx.txt \n\n *HOW TO PLAY* \n\n A boggle board will appear keep on entering all the words \n you can find. When you can't find anymore type in \n done and the results will pop up of how you did! \n");
		String boardx = "board1.txt";
		DictionaryInterface dictionary = new SimpleDictionary();
		DictionaryInterface wordsCorrect = new SimpleDictionary(); //same information as words found
		
		for (int i = 0; i < args.length-1; i++){
			try{
				if (args[i].equals("-b")){
					boardx = args[i+1];
				}
				else if(args[i].equals("-d") && args[i+1].equals("dlb")){
					dictionary = new DLBTrie();
					wordsCorrect = new DLBTrie();
					System.out.println("DLB");
				}
			}
			catch(Exception e){
				System.out.println("Error please use -help and read instrustions carefully \n");
			}
		}
			
		Scanner fileScan = new Scanner(new FileInputStream("dictionary.txt"));
		String inputFromFile;
		StringBuilder potentialWord = new StringBuilder("");
		ArrayList<String> wordsFound = new ArrayList<String>(); //same info as words correct
		ArrayList<String> userGuess = new ArrayList<String>(); 
		
		String [][] board = new String[4][4];
		int [][] trackSpaces = new int [4][4];
		
//load dictionary			
		while (fileScan.hasNext())
		{
			inputFromFile = fileScan.nextLine();
			dictionary.add(inputFromFile);
		}	
//load board game	
		try{
			fileScan = new Scanner(new FileInputStream(boardx));
			String boardGame = fileScan.nextLine();
			int c = 0;
			for(int i = 0 ; i<=3 ; i++){
				for(int j = 0 ; j<=3 ; j++){
					board [i][j] = Character.toString(  Character.toLowerCase(boardGame.charAt(c)) ); //change boardgame to lowercase because dictionary is lowercase
					c++;
				}
			}
		}
		catch(Exception e){
			System.out.println("That board isn't vaild. Try board1.txt board2.txt board3.txt board4.txt board5.txt or board6.txt \n");
			System.exit(0);
		}
		
		fileScan.close();
		
		System.out.println("\n Boggle "+ boardx +"\n\n");

//print out board
		for(int i = 0 ; i<=3 ; i++){
			for(int j = 0 ; j<=3 ; j++){
				System.out.print((board [i][j]).toUpperCase()+" "); //change board back to uppercase for printing purposes. 
			}
			System.out.println("");
		}	
		System.out.println("\n");
		
//ask user to enter words
		String userExit = "";
		System.out.println(" Enter your guesses! (Press the enter key after typing \n new word and when your done guessing type in '*' and see how you did!)\n\n");
		while(!userExit.equals("*")){
			userGuess.add(userExit.toLowerCase());
			Scanner scan = new Scanner(System.in);
			userExit = scan.next();
		}
		
//start looking for words
	    for (int row = 0; row <= 3; row++) {
	        for (int col = 0; col <= 3; col++) {
	        	BoggleSearch(wordsFound, board, trackSpaces, dictionary, wordsCorrect, potentialWord, row, col);
	        }
	    }
	    
//1. Print out what we found
	   System.out.println("Here are all the words on the Board\n");
	   Collections.sort(wordsFound);
	   for(String s : wordsFound){
		   System.out.println(s);
	   }
	   System.out.println("");
//2. Print what they found
	   System.out.println("Here's all the words that you found! \n");
	   int TotalUserFound = 0;
	   for (String s : userGuess){
		   StringBuilder string = new StringBuilder(s);
		   if(wordsCorrect.search(string) == 2 || wordsCorrect.search(string) == 3){
			   System.out.println(string);
			   TotalUserFound++;
		   }
	   }
	  System.out.println("");
	   
//3.  Print how many they found
	  System.out.println("You found "+ TotalUserFound+ " Word(s)!");
//4.  Print total in board
	  System.out.println("There are " + wordsFound.size() + " words in this board");
//5.  Percentage
	  double percent = (((float)TotalUserFound/(float)wordsFound.size())*100);
	  System.out.println("You Found " + percent + "% of the words!");
	   
	}
//end of main
	
	public static void BoggleSearch(ArrayList<String> wordsFound, String [][] board, int [][] trackSpaces, DictionaryInterface dictionary, DictionaryInterface wordsCorrect, StringBuilder potentialWord, int row, int col){

		int ans=0;
		if(col < 0 || col > 3 || row < 0 || row > 3 || trackSpaces[row][col] == 1){
			return;
		}
		
		if(board[row][col].equals("*")){
			for(char alphabet = 'a'; alphabet <= 'z'; alphabet++) {
				potentialWord.append(Character.toString(alphabet));
				ans = dictionary.search(potentialWord);
				runRecursiveSearch(wordsFound, board, trackSpaces, dictionary, wordsCorrect, potentialWord, row, col, ans);
			}
		}
		
		else{
		potentialWord.append(board[row][col]);
		ans = dictionary.search(potentialWord);
		runRecursiveSearch(wordsFound, board, trackSpaces, dictionary, wordsCorrect, potentialWord, row, col, ans);
		}

	}
		
	public static boolean runRecursiveSearch(ArrayList<String> wordsFound, String [][] board, int [][] trackSpaces, DictionaryInterface dictionary, DictionaryInterface wordsCorrect, StringBuilder potentialWord, int row, int col, int ans){
		
		if (ans == 3){
			if(!wordsFound.contains(potentialWord.toString()) && potentialWord.length()>2 ){
			wordsCorrect.add(potentialWord.toString());
			wordsFound.add(potentialWord.toString());
			}

			trackSpaces[row][col] = 1; // track where you've been
			BoggleSearch(wordsFound, board, trackSpaces, dictionary, wordsCorrect, potentialWord, row-1, col-1);
			BoggleSearch(wordsFound, board, trackSpaces, dictionary, wordsCorrect, potentialWord, row-1,   col);
			BoggleSearch(wordsFound, board, trackSpaces, dictionary, wordsCorrect, potentialWord, row-1, col+1);
			BoggleSearch(wordsFound, board, trackSpaces, dictionary, wordsCorrect, potentialWord, row  , col-1);
			BoggleSearch(wordsFound, board, trackSpaces, dictionary, wordsCorrect, potentialWord, row  , col+1);
			BoggleSearch(wordsFound, board, trackSpaces, dictionary, wordsCorrect, potentialWord, row+1, col-1);
			BoggleSearch(wordsFound, board, trackSpaces, dictionary, wordsCorrect, potentialWord, row+1,   col);
			BoggleSearch(wordsFound, board, trackSpaces, dictionary, wordsCorrect, potentialWord, row+1, col+1);
			potentialWord.deleteCharAt(potentialWord.length()-1);
			trackSpaces[row][col] = 0; //hide your steps for the next search
			return true;
		}
				
		if (ans == 2){
			if(!wordsFound.contains(potentialWord.toString()) && potentialWord.length()>2){
			wordsCorrect.add(potentialWord.toString());
			wordsFound.add(potentialWord.toString());
			}	
			potentialWord.deleteCharAt(potentialWord.length()-1);
			trackSpaces[row][col] = 0; //hide your steps for the next search
			return true;
		}
			
		if (ans == 1){
			trackSpaces[row][col] = 1; // track where you've been
			BoggleSearch(wordsFound, board, trackSpaces, dictionary, wordsCorrect, potentialWord, row-1, col-1);
			BoggleSearch(wordsFound, board, trackSpaces, dictionary, wordsCorrect, potentialWord, row-1,   col);
			BoggleSearch(wordsFound, board, trackSpaces, dictionary, wordsCorrect, potentialWord, row-1, col+1);
			BoggleSearch(wordsFound, board, trackSpaces, dictionary, wordsCorrect, potentialWord, row  , col-1);
			BoggleSearch(wordsFound, board, trackSpaces, dictionary, wordsCorrect, potentialWord, row  , col+1);
			BoggleSearch(wordsFound, board, trackSpaces, dictionary, wordsCorrect, potentialWord, row+1, col-1);
			BoggleSearch(wordsFound, board, trackSpaces, dictionary, wordsCorrect, potentialWord, row+1,   col);
			BoggleSearch(wordsFound, board, trackSpaces, dictionary, wordsCorrect, potentialWord, row+1, col+1);
			potentialWord.deleteCharAt(potentialWord.length()-1);
			trackSpaces[row][col] = 0; //hide your steps for the next search
			return true;
		}
		
		if (ans == 0){
			potentialWord.deleteCharAt(potentialWord.length()-1);
			return false;
		}
		
		return false;
	}
}